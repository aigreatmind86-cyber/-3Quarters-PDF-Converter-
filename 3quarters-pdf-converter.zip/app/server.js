require('dotenv').config();
const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const Stripe = require('stripe');
const { PDFDocument } = require('pdf-lib');

const stripe = Stripe(process.env.STRIPE_SECRET_KEY);
const PRICE_CENTS = 75;
const MIN = Math.max(1, parseInt(process.env.MIN_PICTURES || '1', 10)); // 75¢ already clears Stripe's $0.50 minimum
const MAX = 20;
const FORMATS = { 'image/jpeg': 'jpeg', 'image/png': 'png', 'image/webp': 'webp', 'application/pdf': 'pdf' };
const EXT = { jpeg: 'jpg', png: 'png', webp: 'webp', pdf: 'pdf' };

const app = express();
const upload = multer({ limits: { fileSize: 25 * 1024 * 1024, files: MAX } });
app.use(express.json());
app.use(express.static('public'));

app.get('/api/config', (_req, res) => res.json({ price: PRICE_CENTS, min: MIN, max: MAX }));

// Start payment
app.post('/api/checkout', async (req, res) => {
  try {
    const n = parseInt(req.body.count, 10);
    if (!(n >= MIN && n <= MAX)) return res.status(400).json({ error: `Choose ${MIN} to ${MAX} pictures.` });
    const base = process.env.BASE_URL;
    const session = await stripe.checkout.sessions.create({
      mode: 'payment',
      line_items: [{ quantity: n, price_data: { currency: 'usd', unit_amount: PRICE_CENTS, product_data: { name: 'Picture format change' } } }],
      metadata: { paid: String(n), used: '0' },
      success_url: `${base}/?session_id={CHECKOUT_SESSION_ID}`,
      cancel_url: `${base}/?canceled=1`,
    });
    res.json({ url: session.url });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Could not start checkout. Try again.' });
  }
});

async function getOrder(id) {
  const s = await stripe.checkout.sessions.retrieve(id);
  if (s.payment_status !== 'paid') return null;
  const paid = parseInt(s.metadata.paid, 10) || 0;
  const used = parseInt(s.metadata.used, 10) || 0;
  return { paid, used, remaining: Math.max(0, paid - used) };
}

// How many conversions are left on an order
app.get('/api/order', async (req, res) => {
  try {
    const o = await getOrder(String(req.query.session_id || ''));
    if (!o) return res.status(402).json({ error: 'This order isn’t paid.' });
    res.json(o);
  } catch { res.status(404).json({ error: 'Order not found.' }); }
});

// Convert pictures (only after payment, only up to the paid count)
app.post('/api/convert', upload.array('files', MAX), async (req, res) => {
  const id = String(req.body.session_id || '');
  const type = String(req.body.format || '');
  const fmt = FORMATS[type];
  const files = req.files || [];
  if (!fmt) return res.status(400).json({ error: 'Pick PDF, JPG, PNG or WEBP.' });
  if (!files.length) return res.status(400).json({ error: 'No pictures received.' });
  let order;
  try { order = await getOrder(id); } catch { return res.status(404).json({ error: 'Order not found.' }); }
  if (!order) return res.status(402).json({ error: 'This order isn’t paid.' });
  if (files.length > order.remaining) return res.status(402).json({ error: `You have ${order.remaining} conversion${order.remaining === 1 ? '' : 's'} left on this order.` });

  const setUsed = (n) => stripe.checkout.sessions.update(id, { metadata: { paid: String(order.paid), used: String(n) } });
  await setUsed(order.used + files.length); // reserve first so a retry can't reuse credits
  try {
    const out = [];
    for (const f of files) {
      if (fmt === 'pdf') {
        const j = await sharp(f.buffer).rotate().flatten({ background: '#ffffff' }).jpeg({ quality: 92 }).toBuffer({ resolveWithObject: true });
        const k = Math.min(1, 842 / Math.max(j.info.width, j.info.height)); // fit page to A4 length
        const doc = await PDFDocument.create();
        const pic = await doc.embedJpg(j.data);
        const page = doc.addPage([j.info.width * k, j.info.height * k]);
        page.drawImage(pic, { x: 0, y: 0, width: j.info.width * k, height: j.info.height * k });
        out.push({ name: f.originalname.replace(/\.[^.]+$/, '') + '.pdf', mime: type, data: Buffer.from(await doc.save()).toString('base64') });
        continue;
      }
      let img = sharp(f.buffer).rotate();
      if (fmt === 'jpeg') img = img.flatten({ background: '#ffffff' }).jpeg({ quality: 92 });
      else if (fmt === 'png') img = img.png();
      else img = img.webp({ quality: 92 });
      const buf = await img.toBuffer();
      out.push({ name: f.originalname.replace(/\.[^.]+$/, '') + '.' + EXT[fmt], mime: type, data: buf.toString('base64') });
    }
    res.json({ files: out, remaining: order.remaining - files.length });
  } catch (e) {
    console.error(e);
    await setUsed(order.used).catch(() => {}); // give the credits back
    res.status(422).json({ error: 'One of the files couldn’t be converted. You were not charged for this attempt.' });
  }
});

app.listen(process.env.PORT || 3000, () => console.log('Running on port ' + (process.env.PORT || 3000)));
